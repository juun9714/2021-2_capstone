
1. Set up python virtual environment (Recommended)

2. Set up viss_backend server

```
$ cd viss_backend
$ pip install -r requirements.txt
```

3. Run viss_backend server

```
$ python manage.py runserver
```